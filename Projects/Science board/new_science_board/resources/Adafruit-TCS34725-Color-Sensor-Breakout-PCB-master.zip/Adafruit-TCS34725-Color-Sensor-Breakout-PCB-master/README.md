Adafruit-TCS34725-Color-Sensor-Breakout-PCB
===========================================

PCB files for the Adafruit TCS34725 Color Sensor Breakouts

Format is EagleCAD schematic and board layout

For more details, check out the product pages at

-----> http://www.adafruit.com/products/1334
-----> http://www.adafruit.com/products/1356

Adafruit invests time and resources providing this open source design, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Designed by Adafruit Industries.  
Creative Commons Attribution, Share-Alike license, check license.txt for more information
All text above must be included in any redistribution