# RB-Dfr-720 - Weatherproof Ultrasonic Sensor w/ Separate Probe
Sample code for [RB-Dfr-720](http://www.robotshop.com/en/weatherproof-ultrasonic-sensor-separate-probe.html)

# Pinout
![pinout](RB-Dfr-720_pinout.png)

# Example wiring
![example wiring](Rb-Dfr-720_wiring_example.png)

# Timing diagram
![timing diagram](RB-Dfr-720_timing_diagram.png)
